// src/redux/store.js
import { configureStore } from '@reduxjs/toolkit'
import authReducer       from './slices/authSlice'
import themeReducer      from './slices/themeSlice'
import watchlistReducer  from './slices/watchlistSlice'
import continueReducer   from './slices/continueSlice'
import contentReducer    from './slices/contentSlice'
import profileReducer    from './slices/profileSlice'

export const store = configureStore({
  reducer: {
    auth:        authReducer,
    theme:       themeReducer,
    watchlist:   watchlistReducer,
    continue:    continueReducer,
    content:     contentReducer,
    profile:     profileReducer,
  },
  // Middleware: default includes thunk, serializability check
})

export default store
