// src/redux/slices/authSlice.js
import { createSlice } from '@reduxjs/toolkit'

// Load persisted auth from localStorage
const saved = JSON.parse(localStorage.getItem('sv_auth') || 'null')

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    isAuthenticated: saved?.isAuthenticated || false,
    user: saved?.user || null,
    loading: false,
    error: null,
  },
  reducers: {
    loginStart(state) {
      state.loading = true
      state.error = null
    },
    loginSuccess(state, { payload }) {
      state.loading = false
      state.isAuthenticated = true
      state.user = payload
      // Persist to localStorage (mock Firebase)
      localStorage.setItem('sv_auth', JSON.stringify({ isAuthenticated: true, user: payload }))
    },
    loginFail(state, { payload }) {
      state.loading = false
      state.error = payload
    },
    logout(state) {
      state.isAuthenticated = false
      state.user = null
      state.error = null
      localStorage.removeItem('sv_auth')
    },
    clearError(state) {
      state.error = null
    },
  },
})

export const { loginStart, loginSuccess, loginFail, logout, clearError } = authSlice.actions

// Thunk: mock authentication with a 800ms delay
export const loginThunk = (email, password) => async (dispatch) => {
  dispatch(loginStart())
  await new Promise(r => setTimeout(r, 800))
  // Accept any email with a password of 6+ chars
  if (!email.includes('@') || password.length < 6) {
    dispatch(loginFail('Invalid email or password (min 6 chars).'))
    return false
  }
  dispatch(loginSuccess({
    email,
    name: email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    uid: `uid_${Date.now()}`,
  }))
  return true
}

export default authSlice.reducer
