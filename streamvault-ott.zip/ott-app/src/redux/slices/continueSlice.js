// src/redux/slices/continueSlice.js
// Tracks playback progress per profile
import { createSlice } from '@reduxjs/toolkit'

const load = () => JSON.parse(localStorage.getItem('sv_continue') || '{}')
const save = (data) => localStorage.setItem('sv_continue', JSON.stringify(data))

// Structure: { [profileId]: { [movieId]: { progress: 0-100, timestamp: Date } } }
const continueSlice = createSlice({
  name: 'continue',
  initialState: load(),
  reducers: {
    updateProgress(state, { payload: { profileId, movieId, progress } }) {
      if (!state[profileId]) state[profileId] = {}
      state[profileId][movieId] = { progress, timestamp: Date.now() }
      save(state)
    },
    removeFromContinue(state, { payload: { profileId, movieId } }) {
      if (state[profileId]) {
        delete state[profileId][movieId]
        save(state)
      }
    },
    clearContinue(state, { payload: profileId }) {
      state[profileId] = {}
      save(state)
    },
  },
})

export const { updateProgress, removeFromContinue, clearContinue } = continueSlice.actions

export const selectContinueList = (state, profileId) =>
  Object.entries(state.continue[profileId] || {})
    .sort(([, a], [, b]) => b.timestamp - a.timestamp)
    .map(([id, data]) => ({ movieId: Number(id), ...data }))

export default continueSlice.reducer
