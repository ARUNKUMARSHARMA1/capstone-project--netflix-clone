// src/redux/slices/profileSlice.js
import { createSlice } from '@reduxjs/toolkit'
import { PROFILES } from '../../data/mockData'

const saved = JSON.parse(localStorage.getItem('sv_profile') || 'null')

const profileSlice = createSlice({
  name: 'profile',
  initialState: {
    profiles: PROFILES,
    activeProfile: saved,
  },
  reducers: {
    selectProfile(state, { payload }) {
      state.activeProfile = payload
      localStorage.setItem('sv_profile', JSON.stringify(payload))
    },
    clearProfile(state) {
      state.activeProfile = null
      localStorage.removeItem('sv_profile')
    },
  },
})

export const { selectProfile, clearProfile } = profileSlice.actions
export default profileSlice.reducer
