// src/redux/slices/contentSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { MOVIES, getByGenre, searchMovies, HOME_ROWS } from '../../data/mockData'

// Simulate async data fetching with a delay (mimics real API)
const simulateFetch = (data, delay = 400) =>
  new Promise(res => setTimeout(() => res(data), delay))

// Async thunks
export const fetchHomeRows = createAsyncThunk('content/homeRows', async () => {
  const rows = HOME_ROWS.map(row => ({
    ...row,
    movies: MOVIES.filter(m => row.ids.includes(m.id)),
  }))
  return await simulateFetch(rows)
})

export const fetchByGenre = createAsyncThunk('content/byGenre', async ({ genre, page = 1 }) => {
  const all = getByGenre(genre)
  const perPage = 12
  const paginated = all.slice((page - 1) * perPage, page * perPage)
  await simulateFetch(null, 300)
  return { movies: paginated, total: all.length, page, genre }
})

export const fetchSearch = createAsyncThunk('content/search', async (query) => {
  await simulateFetch(null, 200)
  return searchMovies(query)
})

const contentSlice = createSlice({
  name: 'content',
  initialState: {
    homeRows:    [],
    genreMovies: [],
    genreTotal:  0,
    genrePage:   1,
    searchResults: [],
    loading:     {},
    errors:      {},
    cache:       {}, // { genre_page: [] } — prevents refetching
  },
  reducers: {
    clearSearch(state) { state.searchResults = [] },
    resetGenre(state)  { state.genreMovies = []; state.genrePage = 1; state.genreTotal = 0 },
  },
  extraReducers: (builder) => {
    // Home rows
    builder
      .addCase(fetchHomeRows.pending,   s => { s.loading.home = true })
      .addCase(fetchHomeRows.fulfilled, (s, { payload }) => {
        s.loading.home = false; s.homeRows = payload
      })
      .addCase(fetchHomeRows.rejected,  (s, { error }) => {
        s.loading.home = false; s.errors.home = error.message
      })
    // Genre
    builder
      .addCase(fetchByGenre.pending,   s => { s.loading.genre = true })
      .addCase(fetchByGenre.fulfilled, (s, { payload }) => {
        s.loading.genre = false
        s.genrePage = payload.page
        s.genreTotal = payload.total
        // Append for infinite scroll
        if (payload.page === 1) s.genreMovies = payload.movies
        else s.genreMovies = [...s.genreMovies, ...payload.movies]
      })
      .addCase(fetchByGenre.rejected,  (s, { error }) => {
        s.loading.genre = false; s.errors.genre = error.message
      })
    // Search
    builder
      .addCase(fetchSearch.pending,   s => { s.loading.search = true })
      .addCase(fetchSearch.fulfilled, (s, { payload }) => {
        s.loading.search = false; s.searchResults = payload
      })
      .addCase(fetchSearch.rejected,  (s, { error }) => {
        s.loading.search = false; s.errors.search = error.message
      })
  },
})

export const { clearSearch, resetGenre } = contentSlice.actions
export default contentSlice.reducer
