// src/redux/slices/watchlistSlice.js
import { createSlice } from '@reduxjs/toolkit'

const load = () => JSON.parse(localStorage.getItem('sv_watchlist') || '{}')
const save = (data) => localStorage.setItem('sv_watchlist', JSON.stringify(data))

// Structure: { [profileId]: [movieId, ...] }
const watchlistSlice = createSlice({
  name: 'watchlist',
  initialState: load(),
  reducers: {
    toggleWatchlist(state, { payload: { profileId, movieId } }) {
      if (!state[profileId]) state[profileId] = []
      const idx = state[profileId].indexOf(movieId)
      if (idx === -1) {
        state[profileId].push(movieId)
      } else {
        state[profileId].splice(idx, 1)
      }
      save(state)
    },
    clearWatchlist(state, { payload: profileId }) {
      state[profileId] = []
      save(state)
    },
  },
})

export const { toggleWatchlist, clearWatchlist } = watchlistSlice.actions
export const selectIsInWatchlist = (state, profileId, movieId) =>
  (state.watchlist[profileId] || []).includes(movieId)
export default watchlistSlice.reducer
