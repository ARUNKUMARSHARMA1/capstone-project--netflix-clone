// src/redux/slices/themeSlice.js
import { createSlice } from '@reduxjs/toolkit'

const saved = localStorage.getItem('sv_theme') || 'dark'

const themeSlice = createSlice({
  name: 'theme',
  initialState: { mode: saved },
  reducers: {
    toggleTheme(state) {
      state.mode = state.mode === 'dark' ? 'light' : 'dark'
      localStorage.setItem('sv_theme', state.mode)
      // Apply class to html element
      document.documentElement.classList.toggle('dark', state.mode === 'dark')
    },
    setTheme(state, { payload }) {
      state.mode = payload
      localStorage.setItem('sv_theme', payload)
      document.documentElement.classList.toggle('dark', payload === 'dark')
    },
  },
})

export const { toggleTheme, setTheme } = themeSlice.actions
export default themeSlice.reducer
