// src/components/Banner/Banner.jsx
import React, { useState, useEffect, useCallback, memo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { toggleWatchlist, selectIsInWatchlist } from '../../redux/slices/watchlistSlice'
import { updateProgress } from '../../redux/slices/continueSlice'
import { getFeatured } from '../../data/mockData'
import { SkeletonBanner } from '../Skeleton/Skeleton'

const FEATURED = getFeatured()

function Banner() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const profile  = useSelector(s => s.profile.activeProfile)
  const [idx,     setIdx]     = useState(0)
  const [loading, setLoading] = useState(true)
  const [imgReady, setImgReady] = useState(false)

  const movie = FEATURED[idx] || FEATURED[0]

  const inWatchlist = useSelector(s =>
    profile ? selectIsInWatchlist(s, profile.id, movie?.id) : false
  )

  // Simulate initial load
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 600)
    return () => clearTimeout(t)
  }, [])

  // Auto-rotate featured items every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setImgReady(false)
      setIdx(i => (i + 1) % FEATURED.length)
    }, 8000)
    return () => clearInterval(timer)
  }, [])

  const handlePlay = useCallback(() => {
    if (profile) dispatch(updateProgress({ profileId: profile.id, movieId: movie.id, progress: 0 }))
    navigate(`/watch/${movie.id}`)
  }, [movie, profile, dispatch, navigate])

  const handleWatchlist = useCallback(() => {
    if (!profile) return
    dispatch(toggleWatchlist({ profileId: profile.id, movieId: movie.id }))
  }, [movie, profile, dispatch])

  if (loading) return <SkeletonBanner />

  return (
    <div className="relative w-full h-[85vh] min-h-[500px] overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          key={movie.id}
          src={movie.backdrop}
          alt={movie.title}
          onLoad={() => setImgReady(true)}
          className={`w-full h-full object-cover transition-opacity duration-700 ${imgReady ? 'opacity-100' : 'opacity-0'}`}
        />
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/10 to-transparent" />

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-end pb-20 md:pb-32 px-4 md:px-16 max-w-3xl animate-slide-up">
        {/* Type badge */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-1.5">
            <span className="font-display text-primary text-2xl">SV</span>
            <span className="text-xs font-bold text-gray-300 tracking-[3px] uppercase">
              {movie.type === 'show' ? 'Series' : 'Film'}
            </span>
          </div>
          <span className="text-gray-500">|</span>
          <span className="text-xs text-gray-400">{movie.year}</span>
          <span className="text-xs border border-gray-500 text-gray-400 px-1.5 py-0.5 rounded">
            {movie.maturity}
          </span>
        </div>

        {/* Title */}
        <h1 className="font-display text-5xl md:text-7xl text-white leading-none mb-4 drop-shadow-2xl">
          {movie.title}
        </h1>

        {/* Rating */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-1.5">
            <span className="text-accent">★</span>
            <span className="text-white font-semibold">{movie.rating}</span>
            <span className="text-gray-400 text-sm">/ 10</span>
          </div>
          <span className="text-gray-500">·</span>
          <span className="text-gray-300 text-sm">{movie.duration}</span>
          <span className="text-gray-500">·</span>
          <div className="flex gap-1.5">
            {movie.genre.slice(0, 3).map(g => (
              <span key={g} className="text-xs text-gray-300 bg-white/10 px-2 py-0.5 rounded-full">{g}</span>
            ))}
          </div>
        </div>

        {/* Description */}
        <p className="text-gray-300 text-sm md:text-base line-clamp-2 mb-6 max-w-xl">
          {movie.description}
        </p>

        {/* Action buttons */}
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handlePlay}
            className="flex items-center gap-2 bg-white hover:bg-gray-200 text-black font-bold px-6 py-3 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
          >
            <svg className="w-5 h-5 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
            Play Now
          </button>

          <button
            onClick={handleWatchlist}
            className={`flex items-center gap-2 font-semibold px-6 py-3 rounded-lg transition-all duration-200 border-2 hover:scale-105 active:scale-95 ${
              inWatchlist
                ? 'border-accent text-accent bg-accent/10 hover:bg-accent/20'
                : 'border-white/40 text-white bg-white/10 hover:bg-white/20'
            }`}
          >
            {inWatchlist ? (
              <><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> In My List</>
            ) : (
              <><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}><path d="M12 5v14M5 12h14"/></svg> Add to List</>
            )}
          </button>

          <button
            onClick={() => navigate(`/watch/${movie.id}`)}
            className="flex items-center gap-2 text-white/70 hover:text-white font-semibold px-4 py-3 rounded-lg transition-all bg-white/5 hover:bg-white/10 border border-white/10"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <circle cx="12" cy="12" r="10"/><path d="M12 8v4m0 4h.01"/>
            </svg>
            More Info
          </button>
        </div>
      </div>

      {/* Dot indicators */}
      <div className="absolute bottom-8 right-8 md:right-16 flex gap-2 z-10">
        {FEATURED.map((_, i) => (
          <button
            key={i}
            onClick={() => { setImgReady(false); setIdx(i) }}
            className={`rounded-full transition-all duration-300 ${
              i === idx ? 'bg-primary w-6 h-2' : 'bg-white/30 w-2 h-2 hover:bg-white/60'
            }`}
            aria-label={`Featured item ${i + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

export default memo(Banner)
