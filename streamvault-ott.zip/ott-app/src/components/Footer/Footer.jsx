// src/components/Footer/Footer.jsx
import React, { memo } from 'react'

function Footer() {
  return (
    <footer className="border-t border-white/5 mt-16 py-10 px-4 md:px-12">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <span className="font-display text-xl text-primary">STREAM</span>
          <span className="font-display text-xl text-white">VAULT</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { title: 'Platform', links: ['Home', 'Movies', 'TV Shows', 'New Releases'] },
            { title: 'Support', links: ['Help Centre', 'Contact Us', 'Devices', 'Accessibility'] },
            { title: 'Legal', links: ['Privacy Policy', 'Terms of Use', 'Cookie Preferences'] },
            { title: 'Connect', links: ['Twitter', 'Instagram', 'Facebook', 'YouTube'] },
          ].map(col => (
            <div key={col.title}>
              <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-3">{col.title}</p>
              <ul className="space-y-2">
                {col.links.map(link => (
                  <li key={link}><a href="#" className="text-gray-500 hover:text-white text-sm transition-colors">{link}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pt-4 border-t border-white/5">
          <p className="text-gray-600 text-xs">© 2025 StreamVault. Built with React + Redux Toolkit.</p>
          <p className="text-gray-600 text-xs">Data powered by mock TMDB-compatible dataset.</p>
        </div>
      </div>
    </footer>
  )
}

export default memo(Footer)
