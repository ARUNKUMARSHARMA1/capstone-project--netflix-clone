// src/components/MovieCard/MovieCard.jsx
import React, { useState, memo, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { toggleWatchlist, selectIsInWatchlist } from '../../redux/slices/watchlistSlice'
import { updateProgress } from '../../redux/slices/continueSlice'

function StarRating({ rating }) {
  const stars = Math.round(rating / 2)
  return (
    <div className="flex items-center gap-1">
      <span className="text-accent text-xs">{'★'.repeat(stars)}{'☆'.repeat(5 - stars)}</span>
      <span className="text-gray-400 text-xs">{rating}</span>
    </div>
  )
}

function MovieCard({ movie, tall = false, progress = null }) {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const profile   = useSelector(s => s.profile.activeProfile)
  const inWatchlist = useSelector(s =>
    profile ? selectIsInWatchlist(s, profile.id, movie.id) : false
  )
  const [imgLoaded, setImgLoaded] = useState(false)
  const [hovered,   setHovered]   = useState(false)

  const handleClick = useCallback(() => {
    // Mark as started (10% progress) if not already watching
    if (profile && (progress == null)) {
      dispatch(updateProgress({ profileId: profile.id, movieId: movie.id, progress: 0 }))
    }
    navigate(`/watch/${movie.id}`)
  }, [movie.id, profile, progress, dispatch, navigate])

  const handleWatchlist = useCallback((e) => {
    e.stopPropagation()
    if (!profile) return
    dispatch(toggleWatchlist({ profileId: profile.id, movieId: movie.id }))
  }, [profile, movie.id, dispatch])

  const imgSrc = tall ? movie.poster : movie.backdrop

  return (
    <div
      className={`relative flex-shrink-0 cursor-pointer group rounded-lg overflow-hidden transition-all duration-300 ${
        tall ? 'w-32 sm:w-36 h-48 sm:h-52' : 'w-40 sm:w-48 h-26 sm:h-28'
      } ${hovered ? 'scale-105 z-20 shadow-2xl shadow-black/60' : 'scale-100 z-10'}`}
      style={{ height: tall ? undefined : '6.5rem' }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
      aria-label={`Watch ${movie.title}`}
    >
      {/* Image */}
      <div className="absolute inset-0 bg-card">
        {!imgLoaded && <div className="skeleton absolute inset-0" />}
        <img
          src={imgSrc}
          alt={movie.title}
          loading="lazy"
          onLoad={() => setImgLoaded(true)}
          className={`w-full h-full object-cover transition-opacity duration-300 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
        />
      </div>

      {/* Progress bar */}
      {progress != null && (
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
          <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* Hover overlay */}
      <div className={`absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent transition-opacity duration-200 ${hovered ? 'opacity-100' : 'opacity-0'}`}>
        <div className="absolute bottom-0 left-0 right-0 p-2">
          <p className="text-white text-xs font-semibold line-clamp-1 mb-1">{movie.title}</p>
          <StarRating rating={movie.rating} />
          <div className="flex gap-1 mt-1.5">
            {/* Genre badges */}
            {movie.genre.slice(0, 2).map(g => (
              <span key={g} className="text-xs bg-white/20 text-white/90 px-1.5 py-0.5 rounded-full">{g}</span>
            ))}
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            {/* Play */}
            <button
              onClick={handleClick}
              className="flex items-center justify-center w-7 h-7 bg-white rounded-full hover:bg-gray-200 transition-colors"
              aria-label="Play"
            >
              <svg className="w-3.5 h-3.5 text-black ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                <polygon points="5,3 19,12 5,21"/>
              </svg>
            </button>
            {/* Watchlist */}
            <button
              onClick={handleWatchlist}
              className={`flex items-center justify-center w-7 h-7 rounded-full border-2 transition-colors ${
                inWatchlist ? 'border-accent bg-accent/20 text-accent' : 'border-white/50 text-white hover:border-white'
              }`}
              aria-label={inWatchlist ? 'Remove from list' : 'Add to list'}
            >
              {inWatchlist ? (
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                </svg>
              ) : (
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}>
                  <path d="M12 5v14M5 12h14"/>
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Type badge */}
      {movie.type === 'show' && (
        <div className="absolute top-1.5 left-1.5">
          <span className="text-xs bg-primary/90 text-white px-1.5 py-0.5 rounded font-medium">TV</span>
        </div>
      )}
    </div>
  )
}

// Memoize to prevent re-renders when parent state changes unrelated to this card
export default memo(MovieCard)
