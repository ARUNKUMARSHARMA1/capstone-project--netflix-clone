// src/components/Loader/Loader.jsx
import React from 'react'

function Loader({ fullscreen = false, message = 'Loading…', size = 'md' }) {
  const sizes = { sm: 'w-6 h-6', md: 'w-10 h-10', lg: 'w-16 h-16' }
  const ring = sizes[size]

  const content = (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <div className={`${ring} rounded-full border-4 border-white/10 border-t-primary animate-spin`} />
        <div className={`absolute inset-0 flex items-center justify-center text-primary font-display text-xs`}>
          {size === 'lg' ? 'SV' : ''}
        </div>
      </div>
      {message && <p className="text-gray-400 text-sm animate-pulse">{message}</p>}
    </div>
  )

  if (!fullscreen) return content

  return (
    <div className="fixed inset-0 bg-surface z-50 flex items-center justify-center">
      {content}
    </div>
  )
}

export default React.memo(Loader)
