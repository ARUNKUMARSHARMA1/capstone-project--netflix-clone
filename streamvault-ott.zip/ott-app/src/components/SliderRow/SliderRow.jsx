// src/components/SliderRow/SliderRow.jsx
import React, { useRef, useState, memo } from 'react'
import MovieCard from '../MovieCard/MovieCard'

function SliderRow({ title, movies = [], tall = false }) {
  const trackRef = useRef(null)
  const [canLeft,  setCanLeft]  = useState(false)
  const [canRight, setCanRight] = useState(true)

  const SCROLL = 700

  const checkBounds = () => {
    const el = trackRef.current
    if (!el) return
    setCanLeft(el.scrollLeft > 10)
    setCanRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 10)
  }

  const scroll = (dir) => {
    trackRef.current?.scrollBy({ left: dir === 'r' ? SCROLL : -SCROLL, behavior: 'smooth' })
    setTimeout(checkBounds, 450)
  }

  if (!movies.length) return null

  return (
    <section className="mb-8 md:mb-12 group/row">
      {/* Title */}
      <div className="flex items-center gap-2 px-4 md:px-12 mb-3">
        <h2 className="text-base md:text-lg font-bold text-white">{title}</h2>
        <span className="text-primary text-xs font-semibold opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center gap-1">
          See all <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}><path d="M9 5l7 7-7 7"/></svg>
        </span>
      </div>

      <div className="relative">
        {/* Left arrow */}
        {canLeft && (
          <button
            onClick={() => scroll('l')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-full bg-gradient-to-r from-surface to-transparent flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity"
            aria-label="Scroll left"
          >
            <div className="w-8 h-8 bg-card/90 rounded-full flex items-center justify-center shadow-lg border border-white/10 hover:bg-card transition-colors">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}>
                <path d="M15 19l-7-7 7-7"/>
              </svg>
            </div>
          </button>
        )}

        {/* Cards track */}
        <div
          ref={trackRef}
          onScroll={checkBounds}
          className="flex gap-3 overflow-x-auto scrollbar-hide px-4 md:px-12 pb-2"
        >
          {movies.map(movie => (
            <MovieCard key={movie.id} movie={movie} tall={tall} />
          ))}
        </div>

        {/* Right arrow */}
        {canRight && (
          <button
            onClick={() => scroll('r')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-16 h-full bg-gradient-to-l from-surface to-transparent flex items-center justify-end pr-2 opacity-0 group-hover/row:opacity-100 transition-opacity"
            aria-label="Scroll right"
          >
            <div className="w-8 h-8 bg-card/90 rounded-full flex items-center justify-center shadow-lg border border-white/10 hover:bg-card transition-colors">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}>
                <path d="M9 5l7 7-7 7"/>
              </svg>
            </div>
          </button>
        )}
      </div>
    </section>
  )
}

export default memo(SliderRow)
