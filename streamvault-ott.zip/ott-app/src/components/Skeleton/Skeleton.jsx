// src/components/Skeleton/Skeleton.jsx
import React from 'react'

// Reusable skeleton loader shapes
export function SkeletonCard({ tall = false }) {
  return (
    <div className={`flex-shrink-0 rounded-lg overflow-hidden ${tall ? 'w-36 h-52' : 'w-44 h-28'}`}>
      <div className="skeleton w-full h-full" />
    </div>
  )
}

export function SkeletonBanner() {
  return (
    <div className="w-full h-[85vh] skeleton" />
  )
}

export function SkeletonRow() {
  return (
    <div className="px-4 md:px-12 mb-10">
      <div className="skeleton h-5 w-48 rounded mb-4" />
      <div className="flex gap-3">
        {Array.from({ length: 7 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    </div>
  )
}

export function SkeletonGrid({ count = 12 }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="rounded-lg overflow-hidden">
          <div className="skeleton aspect-video w-full rounded-lg" />
          <div className="skeleton h-3 w-3/4 rounded mt-2" />
          <div className="skeleton h-3 w-1/2 rounded mt-1" />
        </div>
      ))}
    </div>
  )
}

export default { SkeletonCard, SkeletonBanner, SkeletonRow, SkeletonGrid }
