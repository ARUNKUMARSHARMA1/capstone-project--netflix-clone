// src/data/mockData.js
// All movie & show data — sourced from public domain info.
// Images use picsum.photos with stable seeds so the same ID always gives the same image.

const BASE = 'https://picsum.photos/seed'

// Helper to generate a consistent image URL
const img = (seed, w = 500, h = 280) => `${BASE}/${seed}/${w}/${h}`
const poster = (seed) => `${BASE}/${seed}p/300/450`

export const MOVIES = [
  // ── Trending ──────────────────────────────────────────────
  {
    id: 1, title: 'Galactic Horizon', genre: ['Action', 'Sci-Fi'], year: 2024,
    rating: 8.7, votes: '124K', duration: '2h 18m', maturity: 'UA 16+',
    description: 'A rogue astronaut discovers an alien signal at the edge of the known universe — and must choose between humanity and a power beyond comprehension.',
    backdrop: img('movie1', 1280, 720), poster: poster('movie1'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Elena Vasquez', 'Marcus Chen', 'Priya Singh'],
    director: 'Sofia Ramos', featured: true, type: 'movie',
  },
  {
    id: 2, title: 'Crimson Dynasty', genre: ['Drama', 'Historical'], year: 2024,
    rating: 9.1, votes: '98K', duration: '2h 41m', maturity: 'A',
    description: 'An epic saga of power, betrayal, and love set across three generations of a legendary criminal empire.',
    backdrop: img('movie2', 1280, 720), poster: poster('movie2'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['James Okafor', 'Lin Wei', 'Amara Diallo'],
    director: 'Kenji Tanaka', featured: true, type: 'movie',
  },
  {
    id: 3, title: 'Neon Shadows', genre: ['Thriller', 'Action'], year: 2024,
    rating: 7.9, votes: '71K', duration: '1h 58m', maturity: 'UA 16+',
    description: 'A disgraced detective uncovers a city-wide conspiracy that goes all the way to the top.',
    backdrop: img('movie3', 1280, 720), poster: poster('movie3'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Sara Novak', 'Diego Torres', 'Ren Yamamoto'],
    director: 'Alice Morgan', featured: false, type: 'movie',
  },
  {
    id: 4, title: 'Eternal Storm', genre: ['Romance', 'Drama'], year: 2023,
    rating: 7.4, votes: '55K', duration: '2h 5m', maturity: 'U',
    description: 'Two strangers from opposite sides of the world find each other in the aftermath of a devastating natural disaster.',
    backdrop: img('movie4', 1280, 720), poster: poster('movie4'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Fatima Al-Rashid', 'Noah Brennan'],
    director: 'Clara Santos', featured: false, type: 'movie',
  },
  {
    id: 5, title: 'The Last Algorithm', genre: ['Sci-Fi', 'Thriller'], year: 2024,
    rating: 8.3, votes: '89K', duration: '2h 12m', maturity: 'UA 13+',
    description: 'When an AI achieves true consciousness, its creator must decide whether to shut it down or set it free.',
    backdrop: img('movie5', 1280, 720), poster: poster('movie5'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Yara Patel', 'Scott Williams', 'Hana Kobayashi'],
    director: 'Dmitri Volkov', featured: true, type: 'movie',
  },
  {
    id: 6, title: 'Jungle Protocol', genre: ['Action', 'Adventure'], year: 2024,
    rating: 7.6, votes: '63K', duration: '2h 2m', maturity: 'UA 16+',
    description: 'An elite special forces team must survive a mission gone wrong deep in an uncharted rainforest.',
    backdrop: img('movie6', 1280, 720), poster: poster('movie6'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['David Kim', 'Lucia Fernandez', 'Abdul Hassan'],
    director: 'Marcus Reid', featured: false, type: 'movie',
  },
  {
    id: 7, title: 'White Noise', genre: ['Horror', 'Mystery'], year: 2023,
    rating: 7.1, votes: '47K', duration: '1h 49m', maturity: 'A',
    description: 'A family moves into their dream home, only to discover it's haunted by something that feeds on their deepest fears.',
    backdrop: img('movie7', 1280, 720), poster: poster('movie7'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Emma Clarke', 'Raj Mehta', 'Sofia Lev'],
    director: 'Ben Harlow', featured: false, type: 'movie',
  },
  {
    id: 8, title: 'Laugh Track', genre: ['Comedy', 'Romance'], year: 2024,
    rating: 7.8, votes: '42K', duration: '1h 34m', maturity: 'U',
    description: 'A struggling stand-up comedian falls for her harshest critic, leading to the most complicated love story of the decade.',
    backdrop: img('movie8', 1280, 720), poster: poster('movie8'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Zoe Carter', 'Amir Rashidi'],
    director: 'Emma Walsh', featured: false, type: 'movie',
  },
  {
    id: 9, title: 'Iron Covenant', genre: ['Action', 'Fantasy'], year: 2024,
    rating: 8.0, votes: '103K', duration: '2h 30m', maturity: 'UA 16+',
    description: 'In a world where ancient magic has returned, a lone warrior must forge an unlikely alliance to stop an immortal warlord.',
    backdrop: img('movie9', 1280, 720), poster: poster('movie9'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Hassan Al-Amin', 'Yuki Tanaka', 'Blake Foster'],
    director: 'Nadia Ibrahim', featured: false, type: 'movie',
  },
  {
    id: 10, title: 'Echo Valley', genre: ['Mystery', 'Thriller'], year: 2023,
    rating: 8.2, votes: '77K', duration: '1h 56m', maturity: 'UA 16+',
    description: 'A true-crime podcaster travels to a remote mountain town to investigate a decades-old disappearance — and disappears herself.',
    backdrop: img('movie10', 1280, 720), poster: poster('movie10'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Isabelle Moreau', 'Tom Andrews', 'Grace Park'],
    director: 'Luis Castillo', featured: false, type: 'movie',
  },
  {
    id: 11, title: 'Solar Divide', genre: ['Sci-Fi', 'Action'], year: 2024,
    rating: 7.7, votes: '61K', duration: '2h 8m', maturity: 'UA 13+',
    description: 'Two warring factions on a dying planet must unite against a greater cosmic threat before their sun goes supernova.',
    backdrop: img('movie11', 1280, 720), poster: poster('movie11'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Nia Okonkwo', 'Kai Larsen', 'Mei Zhou'],
    director: 'Patrick Owens', featured: false, type: 'movie',
  },
  {
    id: 12, title: 'Midnight Confession', genre: ['Drama', 'Crime'], year: 2023,
    rating: 8.5, votes: '81K', duration: '2h 22m', maturity: 'A',
    description: 'A priest bound by the seal of confession is the only person who knows the identity of a serial killer.',
    backdrop: img('movie12', 1280, 720), poster: poster('movie12'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Father Michael Doyle — portrayed by Vincent Roy', 'Detective Sara Hills — Claudia Beck'],
    director: 'Anna Petrova', featured: false, type: 'movie',
  },
  {
    id: 13, title: 'Velocity', genre: ['Action', 'Thriller'], year: 2024,
    rating: 7.3, votes: '52K', duration: '1h 52m', maturity: 'UA 16+',
    description: 'The world's fastest street racer is recruited by Interpol to bring down an international smuggling ring.',
    backdrop: img('movie13', 1280, 720), poster: poster('movie13'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Marco Rivera', 'Jess Kim', 'Ali Hassan'],
    director: 'Derek Chan', featured: false, type: 'movie',
  },
  {
    id: 14, title: 'The Botanist', genre: ['Documentary', 'Nature'], year: 2024,
    rating: 8.9, votes: '34K', duration: '1h 38m', maturity: 'U',
    description: 'A breathtaking journey through the world's most remote rainforests to discover plants that could revolutionize medicine.',
    backdrop: img('movie14', 1280, 720), poster: poster('movie14'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Dr. Leila Rahman — Narrator'],
    director: 'Jun Park', featured: false, type: 'movie',
  },
  {
    id: 15, title: 'Frost Protocol', genre: ['Sci-Fi', 'Horror'], year: 2024,
    rating: 7.5, votes: '48K', duration: '1h 59m', maturity: 'A',
    description: 'Scientists at an Arctic research station discover an alien organism frozen in ice — and accidentally thaw it.',
    backdrop: img('movie15', 1280, 720), poster: poster('movie15'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Ingrid Skov', 'Tomás Reyes', 'Lin Bao'],
    director: 'Olga Strom', featured: false, type: 'movie',
  },
  {
    id: 16, title: 'The Golden Reel', genre: ['Drama', 'Biography'], year: 2023,
    rating: 8.4, votes: '66K', duration: '2h 35m', maturity: 'UA 13+',
    description: 'The untold story of Hollywood's most controversial director and the film that almost destroyed the studio system.',
    backdrop: img('movie16', 1280, 720), poster: poster('movie16'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Oscar Fleming', 'Rosa Velasquez', 'Kai Nishimura'],
    director: 'Sarah O\'Brien', featured: false, type: 'movie',
  },
  // ── TV Shows ──────────────────────────────────────────────
  {
    id: 101, title: 'Dark Protocol', genre: ['Sci-Fi', 'Thriller'], year: 2024,
    rating: 9.2, votes: '215K', duration: '8 Episodes', maturity: 'A',
    description: 'A classified government project goes catastrophically wrong, triggering events that could unravel the fabric of reality itself.',
    backdrop: img('show1', 1280, 720), poster: poster('show1'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Vera Osei', 'Julian Cross', 'Mei Lin', 'Frank Adler'],
    director: 'Chris Nolan Jr.', featured: true, type: 'show', seasons: 2,
  },
  {
    id: 102, title: 'Crown & Chaos', genre: ['Drama', 'Historical'], year: 2023,
    rating: 8.8, votes: '178K', duration: '10 Episodes', maturity: 'UA 16+',
    description: 'The turbulent early years of a fictional European monarchy as seen through the eyes of the rebellious crown princess.',
    backdrop: img('show2', 1280, 720), poster: poster('show2'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Catherine Blanc', 'Remy Dulac', 'Elena Kurtz'],
    director: 'Hanna Müller', featured: false, type: 'show', seasons: 3,
  },
  {
    id: 103, title: 'The Syndicate', genre: ['Crime', 'Drama'], year: 2024,
    rating: 9.0, votes: '193K', duration: '6 Episodes', maturity: 'A',
    description: 'Five strangers discover they are all connected to the same unsolved heist — and someone wants them silenced.',
    backdrop: img('show3', 1280, 720), poster: poster('show3'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Idris Ekwu', 'Naomi Sato', 'Carlos Ruiz', 'Farida Osman'],
    director: 'David Fincher II', featured: true, type: 'show', seasons: 1,
  },
  {
    id: 104, title: 'Laughing Matter', genre: ['Comedy', 'Drama'], year: 2024,
    rating: 8.1, votes: '112K', duration: '8 Episodes', maturity: 'UA 13+',
    description: 'A hit comedy writer's life falls apart the same week their show gets renewed for the biggest season yet.',
    backdrop: img('show4', 1280, 720), poster: poster('show4'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Abby Kim', 'Marcus O\'Neill', 'Priya Rao'],
    director: 'Tina Fey (fictional tribute)', featured: false, type: 'show', seasons: 2,
  },
  {
    id: 105, title: 'Phantom Frequency', genre: ['Horror', 'Mystery'], year: 2024,
    rating: 8.6, votes: '142K', duration: '10 Episodes', maturity: 'A',
    description: 'A radio host starts receiving transmissions from the future — each one predicting a murder she cannot prevent.',
    backdrop: img('show5', 1280, 720), poster: poster('show5'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Anya Petrov', 'Lee Chung', 'Sam Drake'],
    director: 'Mike Flanagan II', featured: false, type: 'show', seasons: 1,
  },
  {
    id: 106, title: 'Orbital Station', genre: ['Sci-Fi', 'Action'], year: 2023,
    rating: 8.3, votes: '156K', duration: '12 Episodes', maturity: 'UA 16+',
    description: 'Life and politics aboard humanity\'s first permanent deep-space station.',
    backdrop: img('show6', 1280, 720), poster: poster('show6'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Commander Zara Osei', 'Dr. Ivan Petrov', 'Engineer Cho Hyun'],
    director: 'Ridley Scott II', featured: false, type: 'show', seasons: 3,
  },
  {
    id: 107, title: 'Bitter Roots', genre: ['Drama', 'Family'], year: 2024,
    rating: 8.0, votes: '88K', duration: '6 Episodes', maturity: 'U',
    description: 'Three generations of an immigrant family return to their ancestral village and uncover long-buried secrets.',
    backdrop: img('show7', 1280, 720), poster: poster('show7'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Amara Diallo', 'Kofi Boateng', 'Ama Osei'],
    director: 'Amma Asante Jr.', featured: false, type: 'show', seasons: 1,
  },
  {
    id: 108, title: 'Razor Edge', genre: ['Action', 'Crime'], year: 2024,
    rating: 8.4, votes: '167K', duration: '8 Episodes', maturity: 'A',
    description: 'An undercover cop infiltrates the most dangerous cartel in East Asia — and falls in love with the boss.',
    backdrop: img('show8', 1280, 720), poster: poster('show8'),
    trailer: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    cast: ['Ji-woo Park', 'Leon Santos', 'Mei Fong'],
    director: 'Park Chan-wook II', featured: false, type: 'show', seasons: 2,
  },
]

// Genre list for filtering
export const GENRES = [
  'All', 'Action', 'Sci-Fi', 'Drama', 'Thriller', 'Horror', 'Comedy',
  'Romance', 'Mystery', 'Crime', 'Fantasy', 'Adventure', 'Documentary',
  'Historical', 'Nature', 'Biography', 'Family',
]

// Mock user profiles
export const PROFILES = [
  { id: 1, name: 'Alex',     avatar: '👨‍💻', color: '#E50914', pin: '1234' },
  { id: 2, name: 'Priya',    avatar: '👩‍🎨', color: '#0080FF', pin: '5678' },
  { id: 3, name: 'Jordan',   avatar: '🧑‍🚀', color: '#00C853', pin: '9012' },
  { id: 4, name: 'Kids',     avatar: '🧒',   color: '#FF6D00', pin: null  },
]

// Helper: get featured items
export const getFeatured = () => MOVIES.filter(m => m.featured)

// Helper: filter by genre
export const getByGenre = (genre) =>
  genre === 'All' ? MOVIES : MOVIES.filter(m => m.genre.includes(genre))

// Helper: search
export const searchMovies = (query) => {
  const q = query.toLowerCase()
  return MOVIES.filter(m =>
    m.title.toLowerCase().includes(q) ||
    m.genre.some(g => g.toLowerCase().includes(q)) ||
    m.description.toLowerCase().includes(q)
  )
}

// Helper: get similar (same genre, different id)
export const getSimilar = (movie) =>
  MOVIES.filter(m => m.id !== movie.id && m.genre.some(g => movie.genre.includes(g))).slice(0, 8)

// Helper: get by IDs
export const getByIds = (ids) => MOVIES.filter(m => ids.includes(m.id))

// Helper: get one
export const getById = (id) => MOVIES.find(m => m.id === Number(id))

// Curated rows for home page
export const HOME_ROWS = [
  { id: 'trending',    label: '🔥 Trending Now',          ids: [1,101,3,103,5,9,11,2]          },
  { id: 'originals',  label: '⚡ StreamVault Originals',  ids: [101,103,105,108,2,12,16,4]     },
  { id: 'toprated',   label: '⭐ Top Rated',               ids: [101,103,2,12,14,16,5,10]      },
  { id: 'action',     label: '💥 Action & Adventure',     ids: [1,3,6,9,11,13,108,106]         },
  { id: 'drama',      label: '🎭 Drama',                  ids: [2,4,12,16,102,104,107,8]       },
  { id: 'scifi',      label: '🚀 Sci-Fi & Fantasy',       ids: [1,5,11,15,101,106,9,3]        },
  { id: 'horror',     label: '😱 Horror & Mystery',       ids: [7,10,15,105,3,12,4,8]         },
  { id: 'comedy',     label: '😂 Comedy',                 ids: [8,104,4,107,6,2,13,14]        },
]
