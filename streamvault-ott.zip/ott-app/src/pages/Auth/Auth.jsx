// src/pages/Auth/Auth.jsx
import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { loginThunk, clearError } from '../../redux/slices/authSlice'
import { useNavigate } from 'react-router-dom'

export default function Auth() {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const { loading, error } = useSelector(s => s.auth)

  const [mode,     setMode]     = useState('login')   // 'login' | 'signup'
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [name,     setName]     = useState('')
  const [confirm,  setConfirm]  = useState('')
  const [localErr, setLocalErr] = useState('')
  const [showPass, setShowPass] = useState(false)

  useEffect(() => { dispatch(clearError()) }, [mode])

  const validate = () => {
    if (!email.includes('@'))   return 'Enter a valid email address.'
    if (password.length < 6)    return 'Password must be at least 6 characters.'
    if (mode === 'signup') {
      if (!name.trim())         return 'Please enter your name.'
      if (password !== confirm) return 'Passwords do not match.'
    }
    return null
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLocalErr('')
    const err = validate()
    if (err) { setLocalErr(err); return }
    const success = await dispatch(loginThunk(email, password))
    if (success) navigate('/profiles')
  }

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-radial from-primary/5 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      {/* Logo bar */}
      <header className="relative z-10 p-6 px-8">
        <div className="flex items-center gap-1">
          <span className="font-display text-2xl text-primary">STREAM</span>
          <span className="font-display text-2xl text-white">VAULT</span>
        </div>
      </header>

      {/* Card */}
      <div className="flex-1 flex items-center justify-center px-4 pb-12">
        <div className="w-full max-w-md animate-scale-in">
          <div className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            {/* Mode tabs */}
            <div className="flex bg-surface/80 rounded-xl p-1 mb-8">
              {['login', 'signup'].map(m => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all duration-200 ${
                    mode === m ? 'bg-primary text-white shadow-lg' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {m === 'login' ? 'Sign In' : 'Create Account'}
                </button>
              ))}
            </div>

            <h1 className="text-2xl font-bold text-white mb-1">
              {mode === 'login' ? 'Welcome back 👋' : 'Join StreamVault 🎬'}
            </h1>
            <p className="text-gray-400 text-sm mb-6">
              {mode === 'login' ? 'Sign in to continue watching' : 'Create your free account today'}
            </p>

            {/* Error message */}
            {(error || localErr) && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-5 flex items-start gap-2 animate-fade-in">
                <span className="text-red-400 text-lg leading-none">⚠</span>
                <p className="text-red-400 text-sm">{localErr || error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name (signup only) */}
              {mode === 'signup' && (
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full bg-surface border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all text-sm"
                    required
                  />
                </div>
              )}

              {/* Email */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-surface border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all text-sm"
                  required
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">Password</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                    className="w-full bg-surface border border-white/10 rounded-xl px-4 py-3 pr-12 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all text-sm"
                    required
                  />
                  <button type="button" onClick={() => setShowPass(s => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors text-xs font-semibold">
                    {showPass ? 'HIDE' : 'SHOW'}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              {mode === 'signup' && (
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1.5">Confirm Password</label>
                  <input
                    type="password"
                    value={confirm}
                    onChange={e => setConfirm(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full bg-surface border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all text-sm"
                    required
                  />
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-3 rounded-xl transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-2"
              >
                {loading ? (
                  <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {mode === 'login' ? 'Signing in…' : 'Creating account…'}</>
                ) : (
                  mode === 'login' ? 'Sign In →' : 'Create Account →'
                )}
              </button>
            </form>

            {/* Demo hint */}
            <div className="mt-5 p-3 bg-white/5 rounded-xl border border-white/10 text-center">
              <p className="text-xs text-gray-400">
                💡 <strong className="text-gray-300">Demo:</strong> Use any email + 6+ char password
              </p>
            </div>
          </div>

          <p className="text-center text-gray-600 text-xs mt-4">
            By continuing, you agree to our Terms of Service & Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  )
}
