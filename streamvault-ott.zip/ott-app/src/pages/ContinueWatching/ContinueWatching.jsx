// src/pages/ContinueWatching/ContinueWatching.jsx
import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { selectContinueList, removeFromContinue, clearContinue } from '../../redux/slices/continueSlice'
import { getByIds } from '../../data/mockData'
import Navbar from '../../components/Navbar/Navbar'
import Footer from '../../components/Footer/Footer'

function ContinueCard({ movie, progress, profileId, onRemove }) {
  const navigate = useNavigate()

  const formatProgress = (pct) => {
    const totalMin = movie.type === 'show' ? 45 : 118
    const watched = Math.round((pct / 100) * totalMin)
    const remaining = totalMin - watched
    return `${remaining}m remaining`
  }

  return (
    <div className="relative group rounded-xl overflow-hidden bg-card border border-white/5 hover:border-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-black/40 hover:-translate-y-1">
      {/* Thumbnail */}
      <div className="aspect-video relative overflow-hidden">
        <img
          src={movie.backdrop}
          alt={movie.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {/* Progress bar overlay */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
          <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
        </div>
        {/* Play overlay on hover */}
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button
            onClick={() => navigate(`/watch/${movie.id}`)}
            className="w-14 h-14 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-110 active:scale-95"
          >
            <svg className="w-6 h-6 text-black ml-1" fill="currentColor" viewBox="0 0 24 24">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
          </button>
        </div>
        {/* Remove button */}
        <button
          onClick={() => onRemove(movie.id)}
          className="absolute top-2 right-2 w-7 h-7 bg-black/60 hover:bg-red-500/80 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
          aria-label="Remove"
        >
          <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}>
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
        {/* Type badge */}
        {movie.type === 'show' && (
          <span className="absolute top-2 left-2 text-xs bg-primary/90 text-white px-1.5 py-0.5 rounded font-medium">TV</span>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="text-white text-sm font-semibold line-clamp-1">{movie.title}</h3>
            <p className="text-gray-500 text-xs mt-0.5">{formatProgress(progress)}</p>
          </div>
          <span className="text-primary text-xs font-bold flex-shrink-0">{Math.round(progress)}%</span>
        </div>

        {/* Progress bar */}
        <div className="mt-2 h-1 bg-white/10 rounded-full">
          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress}%` }} />
        </div>

        {/* Resume button */}
        <button
          onClick={() => navigate(`/watch/${movie.id}`)}
          className="mt-3 w-full flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold py-2 rounded-lg transition-all group-hover:bg-primary group-hover:text-white"
        >
          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
            <polygon points="5,3 19,12 5,21"/>
          </svg>
          Resume
        </button>
      </div>
    </div>
  )
}

export default function ContinueWatching() {
  const dispatch = useDispatch()
  const profile  = useSelector(s => s.profile.activeProfile)
  const list     = useSelector(s => selectContinueList(s, profile?.id))

  // Get actual movie objects in the same order
  const movies = useMemo(() => {
    const ids   = list.map(i => i.movieId)
    const byId  = getByIds(ids)
    // Preserve order from list (sorted by timestamp desc)
    return list
      .map(item => ({ ...item, movie: byId.find(m => m.id === item.movieId) }))
      .filter(item => item.movie && item.progress < 100)
  }, [list])

  const handleRemove = (movieId) => {
    if (!profile) return
    dispatch(removeFromContinue({ profileId: profile.id, movieId }))
  }

  const handleClearAll = () => {
    if (!profile) return
    if (window.confirm('Remove all items from Continue Watching?')) {
      dispatch(clearContinue(profile.id))
    }
  }

  return (
    <div className="min-h-screen bg-surface">
      <Navbar />

      <div className="pt-24 pb-16 px-4 md:px-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Continue Watching</h1>
            <p className="text-gray-400 text-sm mt-1">
              {profile && <><span className="text-white">{profile.avatar} {profile.name}</span> · </>}
              {movies.length} title{movies.length !== 1 ? 's' : ''} in progress
            </p>
          </div>
          {movies.length > 0 && (
            <button
              onClick={handleClearAll}
              className="text-sm text-gray-500 hover:text-red-400 transition-colors flex items-center gap-1.5"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
              Clear All
            </button>
          )}
        </div>

        {movies.length === 0 ? (
          /* Empty state */
          <div className="text-center py-24 animate-fade-in">
            <div className="text-7xl mb-6">▶️</div>
            <h2 className="text-2xl font-bold text-white mb-3">Nothing in progress</h2>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              Start watching a movie or show and it will appear here so you can easily pick up where you left off.
            </p>
            <a href="/"
              className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white font-semibold px-6 py-3 rounded-xl transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
              </svg>
              Browse Content
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 animate-fade-in">
            {movies.map(({ movie, progress, movieId }) => (
              <ContinueCard
                key={movieId}
                movie={movie}
                progress={progress}
                profileId={profile?.id}
                onRemove={handleRemove}
              />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
