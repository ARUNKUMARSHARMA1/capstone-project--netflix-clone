// src/pages/Profiles/Profiles.jsx
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { selectProfile } from '../../redux/slices/profileSlice'
import { logout } from '../../redux/slices/authSlice'

export default function Profiles() {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const profiles  = useSelector(s => s.profile.profiles)
  const user      = useSelector(s => s.auth.user)
  const [pinPrompt, setPinPrompt] = useState(null)
  const [pin,       setPin]       = useState('')
  const [pinError,  setPinError]  = useState('')
  const [hoveredId, setHoveredId] = useState(null)

  const handleSelect = (profile) => {
    // Kids profile requires no PIN, adults with PIN need verification
    if (profile.pin) {
      setPinPrompt(profile)
      setPin('')
      setPinError('')
    } else {
      dispatch(selectProfile(profile))
      navigate('/')
    }
  }

  const handlePinSubmit = (e) => {
    e.preventDefault()
    if (pin === pinPrompt.pin) {
      dispatch(selectProfile(pinPrompt))
      navigate('/')
    } else {
      setPinError('Incorrect PIN. Try again.')
      setPin('')
    }
  }

  const handleLogout = () => {
    dispatch(logout())
    navigate('/auth')
  }

  return (
    <div className="min-h-screen bg-surface flex flex-col items-center justify-center px-4">
      {/* Background pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03]"
        style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '48px 48px' }} />

      {!pinPrompt ? (
        <div className="text-center animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Who's watching?</h1>
          <p className="text-gray-400 mb-10 text-sm">
            Hello, <span className="text-white font-medium">{user?.name || user?.email}</span>!
          </p>

          {/* Profile grid */}
          <div className="flex flex-wrap items-center justify-center gap-6 mb-12">
            {profiles.map(profile => (
              <button
                key={profile.id}
                onClick={() => handleSelect(profile)}
                onMouseEnter={() => setHoveredId(profile.id)}
                onMouseLeave={() => setHoveredId(null)}
                className="flex flex-col items-center gap-3 group"
              >
                <div
                  className={`w-24 h-24 md:w-32 md:h-32 rounded-2xl flex items-center justify-center text-4xl md:text-5xl transition-all duration-200 border-4 ${
                    hoveredId === profile.id ? 'border-white scale-110' : 'border-transparent scale-100'
                  }`}
                  style={{ background: profile.color }}
                >
                  {profile.avatar}
                </div>
                <div className="text-center">
                  <p className={`font-semibold text-sm md:text-base transition-colors ${
                    hoveredId === profile.id ? 'text-white' : 'text-gray-400'
                  }`}>
                    {profile.name}
                  </p>
                  {profile.pin && (
                    <p className="text-xs text-gray-600 mt-0.5">🔒 PIN protected</p>
                  )}
                </div>
              </button>
            ))}

            {/* Add Profile button */}
            <button className="flex flex-col items-center gap-3 group opacity-60 hover:opacity-100 transition-opacity">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl border-2 border-dashed border-white/30 flex items-center justify-center text-4xl hover:border-white/60 transition-colors">
                <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                  <path d="M12 5v14M5 12h14"/>
                </svg>
              </div>
              <p className="text-gray-400 text-sm font-semibold">Add Profile</p>
            </button>
          </div>

          {/* Manage + Sign out */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button className="px-6 py-2.5 border border-white/30 text-gray-300 hover:text-white hover:border-white rounded-lg text-sm font-semibold transition-all">
              Manage Profiles
            </button>
            <button
              onClick={handleLogout}
              className="px-6 py-2.5 text-gray-500 hover:text-red-400 text-sm transition-colors"
            >
              Sign out
            </button>
          </div>
        </div>
      ) : (
        /* PIN entry modal */
        <div className="text-center animate-scale-in">
          <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-4"
            style={{ background: pinPrompt.color }}>
            {pinPrompt.avatar}
          </div>
          <h2 className="text-xl font-bold text-white mb-1">Enter PIN for {pinPrompt.name}</h2>
          <p className="text-gray-400 text-sm mb-6">This profile is PIN protected</p>

          <form onSubmit={handlePinSubmit} className="flex flex-col items-center gap-4">
            <input
              type="password"
              value={pin}
              onChange={e => setPin(e.target.value.slice(0, 4))}
              placeholder="••••"
              maxLength={4}
              className="text-center text-2xl tracking-[1rem] bg-card border border-white/20 rounded-xl px-6 py-3 text-white w-44 focus:outline-none focus:ring-2 focus:ring-primary/50"
              autoFocus
            />
            {pinError && <p className="text-red-400 text-sm">{pinError}</p>}
            <p className="text-gray-600 text-xs">Demo PIN: 1234 / 5678 / 9012</p>
            <div className="flex gap-3">
              <button type="button" onClick={() => setPinPrompt(null)}
                className="px-5 py-2 border border-white/20 text-gray-400 hover:text-white rounded-lg text-sm transition-colors">
                Cancel
              </button>
              <button type="submit"
                className="px-5 py-2 bg-primary hover:bg-primary-dark text-white font-semibold rounded-lg text-sm transition-colors">
                Confirm
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}
