// src/pages/Categories/Categories.jsx
import React, { useEffect, useState, useCallback, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { fetchByGenre, fetchSearch, clearSearch, resetGenre } from '../../redux/slices/contentSlice'
import { GENRES, MOVIES } from '../../data/mockData'
import { useDebounce } from '../../hooks/useDebounce'
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver'
import Navbar from '../../components/Navbar/Navbar'
import MovieCard from '../../components/MovieCard/MovieCard'
import { SkeletonGrid } from '../../components/Skeleton/Skeleton'
import Footer from '../../components/Footer/Footer'

const SORT_OPTIONS = [
  { value: 'rating',    label: 'Top Rated'   },
  { value: 'year',      label: 'Newest First' },
  { value: 'title',     label: 'A → Z'        },
  { value: 'votes',     label: 'Most Popular' },
]

export default function Categories() {
  const dispatch   = useDispatch()
  const navigate   = useNavigate()
  const { genreMovies, genreTotal, genrePage, searchResults, loading } = useSelector(s => s.content)

  const [activeGenre, setActiveGenre] = useState('All')
  const [sortBy,      setSortBy]      = useState('rating')
  const [query,       setQuery]       = useState('')
  const [type,        setType]        = useState('all')   // all | movie | show
  const debouncedQuery = useDebounce(query, 450)

  const isSearching = debouncedQuery.trim().length >= 2
  const hasMore = genreMovies.length < genreTotal

  // Initial fetch
  useEffect(() => {
    dispatch(resetGenre())
    dispatch(fetchByGenre({ genre: activeGenre, page: 1 }))
  }, [activeGenre, dispatch])

  // Search
  useEffect(() => {
    if (isSearching) dispatch(fetchSearch(debouncedQuery.trim()))
    else dispatch(clearSearch())
  }, [debouncedQuery, isSearching, dispatch])

  // Infinite scroll sentinel
  const loadMore = useCallback(() => {
    if (!isSearching && hasMore && !loading.genre) {
      dispatch(fetchByGenre({ genre: activeGenre, page: genrePage + 1 }))
    }
  }, [isSearching, hasMore, loading.genre, activeGenre, genrePage, dispatch])

  const sentinelRef = useIntersectionObserver(loadMore)

  // Sort displayed movies
  const movies = isSearching ? searchResults : genreMovies
  const sorted = [...movies]
    .filter(m => type === 'all' ? true : m.type === type)
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating
      if (sortBy === 'year')   return b.year - a.year
      if (sortBy === 'title')  return a.title.localeCompare(b.title)
      if (sortBy === 'votes')  return parseInt(b.votes) - parseInt(a.votes)
      return 0
    })

  const handleGenreChange = (g) => {
    setActiveGenre(g)
    setQuery('')
    dispatch(clearSearch())
  }

  return (
    <div className="min-h-screen bg-surface">
      <Navbar />
      <div className="pt-24 pb-12 px-4 md:px-12">
        {/* Page header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-1">Browse</h1>
          <p className="text-gray-400 text-sm">
            {isSearching
              ? `${sorted.length} result${sorted.length !== 1 ? 's' : ''} for "${debouncedQuery}"`
              : `${genreTotal} titles in ${activeGenre}`}
          </p>
        </div>

        {/* Search bar */}
        <div className="relative mb-6 max-w-lg">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search titles, genres, cast…"
            className="w-full pl-10 pr-10 py-3 bg-card border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all text-sm"
          />
          {query && (
            <button onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          )}
        </div>

        {/* Filters row */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Genre pills */}
          <div className="flex flex-wrap gap-2 flex-1">
            {GENRES.map(g => (
              <button
                key={g}
                onClick={() => handleGenreChange(g)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                  activeGenre === g && !isSearching
                    ? 'bg-primary text-white scale-105'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          {/* Sort + type filters */}
          <div className="flex items-center gap-3 flex-shrink-0">
            {/* Type filter */}
            <div className="flex bg-card rounded-lg border border-white/10 overflow-hidden">
              {[['all','All'], ['movie','Movies'], ['show','Shows']].map(([v, l]) => (
                <button key={v} onClick={() => setType(v)}
                  className={`px-3 py-1.5 text-xs font-semibold transition-colors ${
                    type === v ? 'bg-primary text-white' : 'text-gray-400 hover:text-white'
                  }`}>
                  {l}
                </button>
              ))}
            </div>

            {/* Sort dropdown */}
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="bg-card border border-white/10 text-gray-300 text-xs font-semibold px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            >
              {SORT_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Results count */}
        {sorted.length > 0 && (
          <p className="text-gray-500 text-xs mb-4">{sorted.length} titles shown</p>
        )}

        {/* Grid */}
        {loading.genre && genreMovies.length === 0 ? (
          <SkeletonGrid count={18} />
        ) : sorted.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-white text-xl font-bold mb-2">No results found</h3>
            <p className="text-gray-400 text-sm">Try a different search or genre.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {sorted.map(movie => (
              <div key={movie.id} className="flex flex-col gap-2 animate-fade-in">
                <div className="aspect-video relative cursor-pointer rounded-lg overflow-hidden group"
                  onClick={() => navigate(`/watch/${movie.id}`)}>
                  <img
                    src={movie.backdrop}
                    alt={movie.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center">
                      <svg className="w-5 h-5 text-black ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                        <polygon points="5,3 19,12 5,21"/>
                      </svg>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-white text-xs font-semibold line-clamp-1">{movie.title}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-accent text-xs">★ {movie.rating}</span>
                    <span className="text-gray-500 text-xs">· {movie.year}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Infinite scroll sentinel */}
        <div ref={sentinelRef} className="h-12 flex items-center justify-center mt-6">
          {loading.genre && genreMovies.length > 0 && (
            <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          )}
          {!hasMore && genreMovies.length > 0 && !isSearching && (
            <p className="text-gray-600 text-xs">All {genreTotal} titles loaded</p>
          )}
        </div>
      </div>
      <Footer />
    </div>
  )
}
