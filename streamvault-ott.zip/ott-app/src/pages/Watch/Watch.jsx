// src/pages/Watch/Watch.jsx
import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { getById, getSimilar } from '../../data/mockData'
import { updateProgress, removeFromContinue } from '../../redux/slices/continueSlice'
import { toggleWatchlist, selectIsInWatchlist } from '../../redux/slices/watchlistSlice'
import Navbar from '../../components/Navbar/Navbar'
import SliderRow from '../../components/SliderRow/SliderRow'
import Footer from '../../components/Footer/Footer'

// ── Mock video player ──────────────────────────────────────
function VideoPlayer({ movie, onProgress }) {
  const [playing,  setPlaying]  = useState(false)
  const [progress, setProgress] = useState(0)
  const [volume,   setVolume]   = useState(80)
  const [muted,    setMuted]    = useState(false)
  const [fullscreen, setFullscreen] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const intervalRef = useRef(null)
  const containerRef = useRef(null)
  let hideTimer = useRef(null)

  // Simulate playback progress when playing
  useEffect(() => {
    if (playing) {
      intervalRef.current = setInterval(() => {
        setProgress(p => {
          const next = Math.min(p + 0.5, 100)
          onProgress(Math.round(next))
          if (next >= 100) { setPlaying(false); clearInterval(intervalRef.current) }
          return next
        })
      }, 500)
    } else {
      clearInterval(intervalRef.current)
    }
    return () => clearInterval(intervalRef.current)
  }, [playing, onProgress])

  const handleMouseMove = useCallback(() => {
    setShowControls(true)
    clearTimeout(hideTimer.current)
    hideTimer.current = setTimeout(() => { if (playing) setShowControls(false) }, 3000)
  }, [playing])

  const formatTime = (pct) => {
    const totalMin = movie.type === 'show' ? 45 : 118
    const mins = Math.round((pct / 100) * totalMin)
    return `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full bg-black overflow-hidden select-none"
      style={{ aspectRatio: '16/9' }}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => playing && setShowControls(false)}
    >
      {/* Background / thumbnail */}
      <img
        src={movie.backdrop}
        alt={movie.title}
        className={`w-full h-full object-cover transition-opacity duration-300 ${playing ? 'opacity-30' : 'opacity-60'}`}
      />

      {/* Play overlay when paused */}
      {!playing && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={() => setPlaying(true)}
            className="w-20 h-20 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95"
            aria-label="Play"
          >
            <svg className="w-9 h-9 text-black ml-1.5" fill="currentColor" viewBox="0 0 24 24">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
          </button>
        </div>
      )}

      {/* Spinning "playing" indicator */}
      {playing && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-white/20 text-6xl font-display animate-pulse">▶</div>
        </div>
      )}

      {/* Controls */}
      <div className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-4 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Progress bar */}
        <div className="mb-3 group">
          <div className="relative h-1 group-hover:h-2 bg-white/20 rounded-full cursor-pointer transition-all duration-150"
            onClick={e => {
              const rect = e.currentTarget.getBoundingClientRect()
              const pct  = ((e.clientX - rect.left) / rect.width) * 100
              setProgress(Math.max(0, Math.min(100, pct)))
            }}>
            <div className="h-full bg-primary rounded-full relative" style={{ width: `${progress}%` }}>
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full shadow opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-white/60 text-xs">{formatTime(progress)}</span>
            <span className="text-white/60 text-xs">{movie.duration}</span>
          </div>
        </div>

        {/* Controls row */}
        <div className="flex items-center gap-3">
          {/* Play/Pause */}
          <button onClick={() => setPlaying(p => !p)}
            className="text-white hover:text-primary transition-colors">
            {playing ? (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <polygon points="5,3 19,12 5,21"/>
              </svg>
            )}
          </button>

          {/* Skip +10 */}
          <button onClick={() => setProgress(p => Math.min(p + 5, 100))}
            className="text-white hover:text-primary transition-colors text-xs font-bold">
            +10
          </button>

          {/* Volume */}
          <div className="flex items-center gap-2">
            <button onClick={() => setMuted(m => !m)} className="text-white hover:text-primary transition-colors">
              {muted || volume === 0 ? (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/>
                </svg>
              )}
            </button>
            <input type="range" min={0} max={100} value={muted ? 0 : volume}
              onChange={e => { setVolume(Number(e.target.value)); setMuted(false) }}
              className="w-16 h-1 accent-primary" />
          </div>

          <span className="text-white/60 text-xs flex-1">{movie.title}</span>

          {/* Fullscreen (visual only) */}
          <button onClick={() => setFullscreen(f => !f)} className="text-white hover:text-primary transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              {fullscreen
                ? <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>
                : <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>
              }
            </svg>
          </button>
        </div>
      </div>

      {/* Mock ad badge */}
      <div className="absolute top-4 right-4 bg-black/60 text-white/50 text-xs px-2 py-1 rounded">
        DEMO PLAYER
      </div>
    </div>
  )
}

// ── Main Watch page ────────────────────────────────────────
export default function Watch() {
  const { id }     = useParams()
  const navigate   = useNavigate()
  const dispatch   = useDispatch()
  const profile    = useSelector(s => s.profile.activeProfile)
  const continueData = useSelector(s => s.continue[profile?.id]?.[id])
  const movie = getById(id)

  const inWatchlist = useSelector(s =>
    profile ? selectIsInWatchlist(s, profile.id, movie?.id) : false
  )

  const handleProgress = useCallback((pct) => {
    if (!profile || !movie) return
    dispatch(updateProgress({ profileId: profile.id, movieId: movie.id, progress: pct }))
  }, [profile, movie, dispatch])

  const handleWatchlist = () => {
    if (!profile || !movie) return
    dispatch(toggleWatchlist({ profileId: profile.id, movieId: movie.id }))
  }

  const handleMarkDone = () => {
    if (!profile || !movie) return
    dispatch(removeFromContinue({ profileId: profile.id, movieId: movie.id }))
  }

  // Scroll to top on navigate
  useEffect(() => { window.scrollTo(0, 0) }, [id])

  if (!movie) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400 mb-4">Content not found.</p>
          <button onClick={() => navigate('/')} className="text-primary hover:text-red-400 transition-colors">
            ← Back to Home
          </button>
        </div>
      </div>
    )
  }

  const similar = getSimilar(movie)

  return (
    <div className="min-h-screen bg-surface">
      <Navbar />

      {/* Video player */}
      <div className="pt-16 bg-black">
        <div className="max-w-7xl mx-auto">
          <VideoPlayer movie={movie} onProgress={handleProgress} />
        </div>
      </div>

      {/* Movie details */}
      <div className="max-w-7xl mx-auto px-4 md:px-12 py-8 animate-slide-up">
        <div className="grid md:grid-cols-[1fr_auto] gap-8">
          {/* Left */}
          <div>
            {/* Back button */}
            <button onClick={() => navigate(-1)}
              className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors mb-4">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path d="M15 19l-7-7 7-7"/>
              </svg>
              Back
            </button>

            {/* Title */}
            <h1 className="font-display text-4xl md:text-6xl text-white mb-3">{movie.title}</h1>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <div className="flex items-center gap-1.5 bg-accent/20 text-accent px-3 py-1 rounded-full">
                <span className="text-base">★</span>
                <span className="font-bold text-sm">{movie.rating}</span>
                <span className="text-xs text-accent/60">({movie.votes} votes)</span>
              </div>
              <span className="text-gray-300 text-sm">{movie.year}</span>
              <span className="text-gray-300 text-sm">·</span>
              <span className="text-gray-300 text-sm">{movie.duration}</span>
              <span className="border border-gray-600 text-gray-400 text-xs px-2 py-0.5 rounded">{movie.maturity}</span>
              {movie.type === 'show' && movie.seasons && (
                <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded font-semibold">
                  {movie.seasons} Season{movie.seasons > 1 ? 's' : ''}
                </span>
              )}
            </div>

            {/* Genres */}
            <div className="flex flex-wrap gap-2 mb-4">
              {movie.genre.map(g => (
                <span key={g} className="bg-white/10 text-gray-300 text-xs px-3 py-1 rounded-full hover:bg-white/20 cursor-pointer transition-colors">
                  {g}
                </span>
              ))}
            </div>

            {/* Description */}
            <p className="text-gray-300 leading-relaxed mb-6 max-w-2xl">{movie.description}</p>

            {/* Action buttons */}
            <div className="flex flex-wrap gap-3 mb-8">
              <button
                onClick={handleWatchlist}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 border-2 ${
                  inWatchlist
                    ? 'border-accent text-accent bg-accent/10 hover:bg-accent/20'
                    : 'border-white/20 text-white bg-white/5 hover:bg-white/10'
                }`}
              >
                {inWatchlist ? (
                  <><svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> In My List</>
                ) : (
                  <><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}><path d="M12 5v14M5 12h14"/></svg> Add to List</>
                )}
              </button>

              {continueData && (
                <button onClick={handleMarkDone}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                    <path d="M5 13l4 4L19 7"/>
                  </svg>
                  Mark as Done
                </button>
              )}
            </div>

            {/* Progress */}
            {continueData && continueData.progress > 0 && (
              <div className="mb-6 p-4 bg-card rounded-xl border border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-white">Continue Watching</span>
                  <span className="text-sm text-primary font-bold">{Math.round(continueData.progress)}%</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${continueData.progress}%` }} />
                </div>
              </div>
            )}

            {/* Cast & Crew */}
            <div className="space-y-3">
              <div>
                <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider">Director</span>
                <p className="text-white text-sm mt-0.5">{movie.director}</p>
              </div>
              <div>
                <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider">Cast</span>
                <p className="text-gray-300 text-sm mt-0.5">{movie.cast.join(', ')}</p>
              </div>
            </div>
          </div>

          {/* Right: Poster */}
          <div className="hidden md:block flex-shrink-0">
            <img src={movie.poster} alt={`${movie.title} poster`}
              className="w-48 rounded-xl shadow-2xl border border-white/10" />
          </div>
        </div>
      </div>

      {/* Similar content */}
      {similar.length > 0 && (
        <div className="mt-4">
          <SliderRow title="🎬 More Like This" movies={similar} />
        </div>
      )}

      <Footer />
    </div>
  )
}
