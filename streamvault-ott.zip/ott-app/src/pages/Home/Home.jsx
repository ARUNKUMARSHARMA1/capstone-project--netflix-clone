// src/pages/Home/Home.jsx
import React, { useEffect, useMemo } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchHomeRows } from '../../redux/slices/contentSlice'
import { MOVIES, getByIds } from '../../data/mockData'
import Navbar from '../../components/Navbar/Navbar'
import Banner from '../../components/Banner/Banner'
import SliderRow from '../../components/SliderRow/SliderRow'
import Footer from '../../components/Footer/Footer'
import { SkeletonRow } from '../../components/Skeleton/Skeleton'

export default function Home() {
  const dispatch = useDispatch()
  const { homeRows, loading } = useSelector(s => s.content)

  // Fetch home rows on mount if not already cached
  useEffect(() => {
    if (!homeRows.length) dispatch(fetchHomeRows())
  }, [dispatch, homeRows.length])

  // useMemo: don't recompute row data on every render
  const rows = useMemo(() => homeRows, [homeRows])

  return (
    <div className="min-h-screen bg-surface dark:bg-surface">
      <Navbar />

      {/* Hero banner */}
      <Banner />

      {/* Content rows */}
      <div className="mt-2 pb-8">
        {loading.home
          ? Array.from({ length: 4 }).map((_, i) => <SkeletonRow key={i} />)
          : rows.map(row => (
              <SliderRow
                key={row.id}
                title={row.label}
                movies={row.movies}
                tall={row.id === 'originals'}
              />
            ))
        }
      </div>

      <Footer />
    </div>
  )
}
